#!/bin/sh

cd "`dirname "$0"`"
nohup ./macos_tray &